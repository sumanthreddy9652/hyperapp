export const format = date => new Date(date).toDateString();
