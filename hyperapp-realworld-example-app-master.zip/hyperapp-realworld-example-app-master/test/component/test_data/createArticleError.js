export default {
    "errors": {
        "title": ["can't be blank", "is too short (minimum is 1 character)"],
        "body": ["can't be blank"],
        "description": ["can't be blank", "is too short (minimum is 1 character)"]
    }
}