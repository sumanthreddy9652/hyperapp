export default {
  "articles": [
    {
      "title": "saeed",
      "slug": "saeed-jetu0l",
      "body": "saeefsaeefsaeefsaeefsaeefsaeefsaeefsaeefsaeefsaeefsaeef",
      "createdAt": "2018-07-11T07:33:39.159Z",
      "updatedAt": "2018-07-11T07:33:39.159Z",
      "tagList": [],
      "description": "saeeedd",
      "author": {
        "username": "saeed",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 0
    },
    {
      "title": "dfasdf",
      "slug": "dfasdf-n203v9",
      "body": "sdfjklasjdfklsadf",
      "createdAt": "2018-07-11T06:28:16.438Z",
      "updatedAt": "2018-07-11T06:28:16.438Z",
      "tagList": [],
      "description": "abc",
      "author": {
        "username": "cuong123456",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 1
    },
    {
      "title": "How to train your dragon",
      "slug": "how-to-train-your-dragon-970bif",
      "body": "Very carefully.",
      "createdAt": "2018-07-11T06:14:16.962Z",
      "updatedAt": "2018-07-11T06:14:16.962Z",
      "tagList": [
        "training",
        "dragons"
      ],
      "description": "Ever wonder how?",
      "author": {
        "username": "joewhatuser",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 1
    },
    {
      "title": "AAAAA",
      "slug": "aaaaa-nni2cq",
      "body": "thôi fafkajlfka",
      "createdAt": "2018-07-11T06:00:48.831Z",
      "updatedAt": "2018-07-11T06:00:48.831Z",
      "tagList": [],
      "description": "B BBB",
      "author": {
        "username": "tuantuantuandz",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 0
    },
    {
      "title": "Hello There",
      "slug": "hello-there-mxjqcq",
      "body": "A TEST!!!!!!",
      "createdAt": "2018-07-11T05:33:45.509Z",
      "updatedAt": "2018-07-11T05:33:45.509Z",
      "tagList": [],
      "description": "My name is....",
      "author": {
        "username": "drbuck10",
        "bio": "I'm hilarious",
        "image": "https://i.kinja-img.com/gawker-media/image/upload/s--VRgSmL1i--/c_scale,f_auto,fl_progressive,q_80,w_800/wsvqhc42bnocrsetkizw.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 1
    },
    {
      "title": "ABC",
      "slug": "abc-gnnxa3",
      "body": "dfsdfsdfsdf",
      "createdAt": "2018-07-11T04:49:28.245Z",
      "updatedAt": "2018-07-11T04:49:28.245Z",
      "tagList": [],
      "description": "abc",
      "author": {
        "username": "yop singh",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 1
    },
    {
      "title": "df",
      "slug": "df-ykdtoo",
      "body": "sdf",
      "createdAt": "2018-07-11T04:11:52.232Z",
      "updatedAt": "2018-07-11T04:11:52.232Z",
      "tagList": [],
      "description": "sdf",
      "author": {
        "username": "testdsfsdfsdf",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 0
    },
    {
      "title": "Article New",
      "slug": "article-new-q8efhz",
      "body": "Nice Example for VueJs",
      "createdAt": "2018-07-11T03:55:51.203Z",
      "updatedAt": "2018-07-11T03:55:51.203Z",
      "tagList": [
        "javascript",
        "frontend",
        "VueJS"
      ],
      "description": "Nice Example for VueJs",
      "author": {
        "username": "drc",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 1
    },
    {
      "title": "Testing",
      "slug": "testing-d0nqzg",
      "body": "Some dummy test",
      "createdAt": "2018-07-11T03:17:09.669Z",
      "updatedAt": "2018-07-11T03:17:09.669Z",
      "tagList": [],
      "description": "attention please",
      "author": {
        "username": "kolibreath",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 1
    },
    {
      "title": "erwr",
      "slug": "erwr-zw7p09",
      "body": "rwerewrew",
      "createdAt": "2018-07-11T02:57:30.342Z",
      "updatedAt": "2018-07-11T02:57:30.342Z",
      "tagList": [],
      "description": "werew",
      "author": {
        "username": "qaudaffyazmi",
        "bio": null,
        "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
        "following": false
      },
      "favorited": false,
      "favoritesCount": 1
    }
  ],
  "articlesCount": 500
}