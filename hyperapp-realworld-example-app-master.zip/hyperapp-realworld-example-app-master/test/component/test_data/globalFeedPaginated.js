export default {
    "articles": [{
        "title": "a",
        "slug": "a-gf8agp",
        "body": "c",
        "createdAt": "2018-07-10T10:42:20.575Z",
        "updatedAt": "2018-07-10T10:42:20.575Z",
        "tagList": [],
        "description": "b",
        "author": {
            "username": "testuser30",
            "bio": "This is a long story ",
            "image": "https://st2.depositphotos.com/3369547/11386/v/950/depositphotos_113863470-stock-illustration-avatar-man-icon-people-design.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "Hello",
        "slug": "hello-6x6wqw",
        "body": "I Dont Know",
        "createdAt": "2018-07-10T09:53:04.263Z",
        "updatedAt": "2018-07-10T09:53:04.263Z",
        "tagList": [],
        "description": "For Online Learners",
        "author": {
            "username": "manikanta6264",
            "bio": null,
            "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "a",
        "slug": "a-4lnea",
        "body": "c",
        "createdAt": "2018-07-10T09:44:32.987Z",
        "updatedAt": "2018-07-10T09:44:32.987Z",
        "tagList": ["dragons"],
        "description": "b",
        "author": {
            "username": "testuser30",
            "bio": "This is a long story ",
            "image": "https://st2.depositphotos.com/3369547/11386/v/950/depositphotos_113863470-stock-illustration-avatar-man-icon-people-design.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "a",
        "slug": "a-gjspn6",
        "body": "c",
        "createdAt": "2018-07-10T09:24:38.486Z",
        "updatedAt": "2018-07-10T09:24:38.486Z",
        "tagList": ["dragons"],
        "description": "b",
        "author": {
            "username": "testuser30",
            "bio": "This is a long story ",
            "image": "https://st2.depositphotos.com/3369547/11386/v/950/depositphotos_113863470-stock-illustration-avatar-man-icon-people-design.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "title",
        "slug": "title-dkbeso",
        "body": "###markdown",
        "createdAt": "2018-07-10T09:09:02.775Z",
        "updatedAt": "2018-07-10T09:09:02.775Z",
        "tagList": [],
        "description": "desc",
        "author": {
            "username": "testuser30",
            "bio": "This is a long story ",
            "image": "https://st2.depositphotos.com/3369547/11386/v/950/depositphotos_113863470-stock-illustration-avatar-man-icon-people-design.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "Intelligent Traffic Light",
        "slug": "intelligent-traffic-light-3rk5v",
        "body": "it will reduce the traffic jams",
        "createdAt": "2018-07-10T08:58:34.902Z",
        "updatedAt": "2018-07-10T08:58:34.902Z",
        "tagList": [],
        "description": "control traffic on roads",
        "author": {
            "username": "kaweesha",
            "bio": null,
            "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "sdfg",
        "slug": "sdfg-gq6wfe",
        "body": "sdg",
        "createdAt": "2018-07-10T08:58:24.066Z",
        "updatedAt": "2018-07-10T08:58:24.066Z",
        "tagList": [],
        "description": "zdg",
        "author": {
            "username": "fgn",
            "bio": null,
            "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "TestArticle11",
        "slug": "testarticle11-cz87ng",
        "body": "Just another description",
        "createdAt": "2018-07-10T08:39:40.969Z",
        "updatedAt": "2018-07-10T08:39:40.969Z",
        "tagList": [],
        "description": "QA Article",
        "author": {
            "username": "bgiggus",
            "bio": null,
            "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 1
    }, {
        "title": "article",
        "slug": "article-4ul0sd",
        "body": "**hello** there\n*my* name is **petre**",
        "createdAt": "2018-07-10T08:25:02.884Z",
        "updatedAt": "2018-07-10T08:25:18.977Z",
        "tagList": ["tag2", "tag1"],
        "description": "testing the article",
        "author": {
            "username": "test234443",
            "bio": null,
            "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }, {
        "title": "Privet blet",
        "slug": "privet-blet-z1kcfz",
        "body": "Poleteli na lunu",
        "createdAt": "2018-07-10T08:07:42.743Z",
        "updatedAt": "2018-07-10T08:07:42.743Z",
        "tagList": [],
        "description": "About you",
        "author": {
            "username": "qwertyzxcvb",
            "bio": null,
            "image": "https://static.productionready.io/images/smiley-cyrus.jpg",
            "following": false
        },
        "favorited": false,
        "favoritesCount": 0
    }], "articlesCount": 500
}