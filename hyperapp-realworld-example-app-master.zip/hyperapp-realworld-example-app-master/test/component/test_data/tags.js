export default {
  "tags": [
    "dragons",
    "training",
    "test",
    "tags",
    "as",
    "coffee",
    "flowers",
    "sushi",
    "money",
    "cookies",
    "happiness",
    "cars",
    "well",
    "japan",
    "caramel",
    "animation",
    "clean",
    "sugar",
    "baby"
  ]
}