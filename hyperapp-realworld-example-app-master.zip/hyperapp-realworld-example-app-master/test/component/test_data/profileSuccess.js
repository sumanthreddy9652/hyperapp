export default {
    "profile": {
        "following": false,
        "username": "testuser",
        "bio": "This is a long story ",
        "image": "https://st2.depositphotos.com/3369547/11386/v/950/depositphotos_113863470-stock-illustration-avatar-man-icon-people-design.jpg"
    }
}